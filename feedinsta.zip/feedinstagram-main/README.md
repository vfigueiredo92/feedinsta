# feedinstagram

Utilizar server.js no jsonserver com a url http://localhost:3000/feed?_expand=author&_limit=4&_page=1
    
Utilizar o server2.js no www.mockapi.io com a url https://5fa103ace21bab0016dfd97e.mockapi.io/api/v1/feed?page=1&limit=4
